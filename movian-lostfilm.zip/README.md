# movian-lostfilm
Plugin for [Movian](https://github.com/andoma/movian) to watch TV series from [lostfilm.tv](http://www.lostfilm.tv).
![Screenshot: main screen](https://habrastorage.org/files/c65/b78/fb6/c65b78fb68ec4f2f90f08cb7f07c20b5.png)
![Screenshot: TV series screen](https://habrastorage.org/files/e5b/52e/203/e5b52e203c364c2a8a87e1959ec72a5b.png)
![Screenshot: settings](https://habrastorage.org/files/26e/033/955/26e03395517b4de0a448c3667cc822e3.png)
